class LogAggregator:
    def collect_logs(self):
        return ["Service running normally"]
